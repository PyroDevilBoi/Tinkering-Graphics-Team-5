import pygame
import sys

pygame.init()
screen = pygame.display.set_mode((1280, 720))
pygame.display.set_caption("Contract 1 Tile Generator")
clock = pygame.time.Clock()

BLACK = 0, 0, 0
WHITE = 255, 255, 255
RED = 255, 0, 0

Tiles = ("grass", "stone", "sand")

Grass_color = 0, 204, 0
Stone_color = 128, 128, 128
Sand_color = 218, 183, 12

tile = str(input("Enter which tile you would like, selection is: Grass, Stone, Sand: "))

tile.lower

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            screen.fill(BLACK)

        if tile == "sand":
            pygame.draw.rect(screen, Sand_color, (10, 10, 50, 50))
        elif tile == "stone":
            pygame.draw.rect(screen, Stone_color, (10, 10, 50, 50))
        elif tile == "grass":
            pygame.draw.rect(screen, Grass_color, (10, 10, 50, 50))
        else:
            pygame.draw.rect(screen, WHITE, (10, 10, 50, 50))

        pygame.display.flip()

sys.exit()
