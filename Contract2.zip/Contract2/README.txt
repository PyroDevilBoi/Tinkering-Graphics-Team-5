
# # # Tinkering graphics assignment: Contract 2 # # #

This is conract 2, to use this program all you do is open it using PyCharm and hit the run button(or F5 key). 
To get the tiles type in grass, sand or stone and the box will appear to match the colour of the specified input.

We aim to improve the code darasticly in future by adding future and much more varied tiles aswell as the ability
to input multiple with different attributes.

This was coded by both Toby Atkinsob and Philip Hutchings, we both took in turns doing the programming.