# Tinkering-Graphics-Team-5

Requires the following libraries: pygame, sys, os, random
Requires folders that contain specific .png images in order to work: heads, bodies, arms, legs

[Repository link](https://github.com/PyroDevilBoi/Tinkering-Graphics-Team-5/)
