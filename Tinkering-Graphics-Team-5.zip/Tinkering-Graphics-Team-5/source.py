import pygame, sys, os, random




#Contract made by Adrian Tofan


pygame.init()

WINDOWWIDTH = 1600
WINDOWHEIGHT = 1000
imageScaleX = 1000
imageScaleY = 660



#Go over each folder of body parts and load the images into lists
def image_load(heads, bodies, arms, legs):


    for head in os.listdir('heads'):
        if head.endswith('.png'):
            path = os.path.join('heads', head)
            heads.append(pygame.image.load(path))


    for body in os.listdir('bodies'):
        if body.endswith('.png'):
            path = os.path.join('bodies', body)
            bodies.append(pygame.image.load(path))

    for arm in os.listdir('arms'):
        if arm.endswith('.png'):
            path = os.path.join('arms', arm)
            arms.append(pygame.image.load(path))

    for leg in os.listdir('legs'):
        if body.endswith('.png'):
            path=os.path.join('legs', leg)
            legs.append(pygame.image.load(path))


def loadBackground():
    #YELLOW = (255, 236, 139)
    BACKGROUND = pygame.image.load('background.png')
    displaysurf.blit(BACKGROUND, (0, 0))


def generateXrandom():
    return random.randrange(1100)


def generateYrandom():
    return random.randrange(300, 500)


#def generateRandom():
   # return random.randrange(1600)

def checkIfRunning(runs):
    if runs == False:
        pygame.quit()
        sys.exit()


def checkIfButtonPressed(x, y):
    if (x >= 1500 and x <= 1590) and (y >= 100 and y <= 130):
        return True


def load_button_text(surf):
    pygame.font.init()
    FONT = pygame.font.SysFont('Aerial', 15)
    TEXT = FONT.render('GENERATE', False, (255, 255, 255))
    surf.blit(TEXT, (1517, 107))


def load_button(surf):

    PINK = (150, 80, 100)
    pygame.draw.rect(surf, PINK, (1500, 100, 90, 30))
    #pygame.draw.rect(surf, PINK, (1500, 100, 50, 30))
    load_button_text(surf)



def shuffle(bodyPart):
    random.shuffle(bodyPart)




def generate_enemy(x, y, heads, bodies, arms, legs):

        shuffle(heads)
        shuffle(bodies)
        shuffle(arms)
        shuffle(legs)
        heads[0] = pygame.transform.scale(heads[0], (imageScaleX, imageScaleY))
        bodies[0] = pygame.transform.scale(bodies[0], (imageScaleX, imageScaleY))
        arms[0] = pygame.transform.scale(arms[0], (imageScaleX, imageScaleY))
        legs[0] = pygame.transform.scale(legs[0], (imageScaleX, imageScaleY))
        displaysurf.blit(heads[0], (x, y))
        displaysurf.blit(bodies[0], (x, y))
        displaysurf.blit(arms[0], (x, y))
        displaysurf.blit(legs[0], (x, y))

        pygame.display.update()



def main():
    global displaysurf, FPS, fpsClock
    FPS = 30
    fpsClock = pygame.time.Clock()
    heads = []
    bodies = []
    arms = []
    legs = []

    displaysurf = pygame.display.set_mode((WINDOWWIDTH,WINDOWHEIGHT))
    pygame.display.set_caption('Creature generator by Adrian Tofan')

    image_load(heads, bodies, arms, legs)
    shuffle(heads)
    # a = generateRandom()
    running = True
    generating = True


    while running:



            loadBackground()
            load_button(displaysurf)

            for i in range(3):
                x = generateXrandom()
                y = generateYrandom()

                generate_enemy(x, y, heads, bodies, arms, legs)

            generating = False

            while generating == False:
             for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    checkIfRunning(running)
                    pygame.display.update()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    spotX, spotY = event.pos[0], event.pos[1]
                    if checkIfButtonPressed(spotX, spotY):
                        generating = True
                        pygame.display.update()



    pygame.display.update()
    fpsClock.tick(FPS)




if __name__ == '__main__':
    main()




